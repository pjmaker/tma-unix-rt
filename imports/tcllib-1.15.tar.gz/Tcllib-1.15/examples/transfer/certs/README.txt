These certificates have been created with SimpleCA,
see http://wiki.tcl.tk/11419
and http://users.skynet.be/ballet/joris/SimpleCA/
